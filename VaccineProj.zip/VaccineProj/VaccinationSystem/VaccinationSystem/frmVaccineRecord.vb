﻿Public Class frmVaccineRecord
    Private Sub frmVaccineRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class