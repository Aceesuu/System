﻿Imports System.Data
Imports System.Data.SqlClient

Public Class frmRegistration
    Dim con As SqlConnection
    Dim cmd As SqlCommand
    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim con As New SqlConnection("Data Source=ACE\SQLEXPRESS;Initial Catalog=TBVaccineSystem;Integrated Security=True")
        Dim cmd As New SqlCommand("INSERT INTO [dbo].[Register]
           ([First_Name]
           ,[Middle_Initial]
           ,[Last_Name]
           ,[Username]
           ,[Password]
           ,[Date_Of_Birth]
           ,[Address]
           ,[Email]
           ,[Contact_Number]
           ,[Gender])
     VALUES
     ('" + txtFname.Text + "','" + txtMidIni.Text + "','" + txtLastName.Text + "','" + txtUsername.Text + "','" + txtPass.Text + "','" + Birthdate.Value + "','" + txtAddress.Text + "','" + txtEmail.Text + "','" + TxtNum.Text + "','" + cboGender.SelectedItem.ToString() + "')", con)
        con.Open()
        cmd.ExecuteNonQuery()
        MessageBox.Show("You are now REGISTERED!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information)
        con.Close()

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub btnGet_Click(sender As Object, e As EventArgs) Handles btnGet.Click
        Try
            Dim num As Integer = 0
            con = New SqlConnection("Data Source=ACE\SQLEXPRESS;Initial Catalog=TBVaccineSystem;Integrated Security=True")
            con.Open()
            Dim sql As String = "SELECT MAX(Regis_Id) from [dbo].[Register]"
            cmd = New SqlCommand(sql)
            cmd.Connection = con
            If (IsDBNull(cmd.ExecuteScalar)) Then
                num = 1
                txtReg.Text = "VAXX_" + num.ToString
            Else
                num = cmd.ExecuteScalar + 1
                txtReg.Text = "VAXX_" + num.ToString
            End If
            con.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Class