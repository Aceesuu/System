﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmLogin
    Dim con As New SqlConnection("Data Source=ACE\SQLEXPRESS;Initial Catalog=TBVaccineSystem;Integrated Security=True")

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If txtUsername.Text = "" Or txtPassword.Text = "" Then
            MessageBox.Show("All fields are required")
        Else
            Try
                con.Open()
                Using cmd As New SqlCommand("SELECT * FROM TB_Login WHERE [USERNAME]=@USERNAME OR [PASSWORD] =@PASSWORD", con)
                    cmd.Parameters.AddWithValue("@USERNAME", txtUsername.Text)
                    cmd.Parameters.AddWithValue("@PASSWORD", txtPassword.Text)

                    Dim ds As New SqlDataAdapter(cmd)
                    Dim Login As New DataTable
                    ds.Fill(Login)

                    If Login.Rows(0)("USERTYPE") = "Admin" Then
                        Dim message As String = "You have successfully login"
                        Dim caption As String = "Success"
                        Dim result = MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Information)

                        Dim AdminMain As New frmProfileAdmin
                        frmProfileAdmin.AdminMain = txtUsername.Text
                        frmProfileAdmin.Show()
                        frmProfileUser.Hide()

                    ElseIf Login.Rows(0)("USERTYPE") = "User" Then
                        Dim message As String = "You have successfully login"
                        Dim caption As String = "Success"
                        Dim result = MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        Dim userMain As New frmProfileUser
                        frmProfileUser.userMain = txtUsername.Text
                        frmProfileUser.Show()
                    Else
                        MessageBox.Show("Wrong password or user name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        txtUsername.Text = ""
                        txtPassword.Text = ""
                    End If

                End Using
            Catch ex As Exception
                MessageBox.Show("Wrong password or user name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Finally
                con.Close()
            End Try

        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        frmHomepage.ShowDialog()
        Me.Hide()
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        frmRegistration.ShowDialog()
        Me.Hide()
    End Sub
End Class