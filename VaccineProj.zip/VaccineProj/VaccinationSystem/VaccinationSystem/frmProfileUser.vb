﻿Public Class frmProfileUser
    Public Shared userMain
    Private Sub btnPersonal_Click(sender As Object, e As EventArgs) Handles btnPersonal.Click
        With frmPersonalDetails
            .TopLevel = False
            Panel2.Controls.Add(frmPersonalDetails)
            .BringToFront()
            .Show()
            frmAppointment.Hide()
            frmVaccineRecord.Hide()
        End With
    End Sub

    Private Sub btnRecord_Click(sender As Object, e As EventArgs) Handles btnRecord.Click
        With frmVaccineRecord
            .TopLevel = False
            Panel2.Controls.Add(frmVaccineRecord)
            .BringToFront()
            .Show()
            frmPersonalDetails.Hide()
            frmAppointment.Hide()
        End With
    End Sub

    Private Sub btnAppoint_Click(sender As Object, e As EventArgs) Handles btnAppoint.Click
        With frmAppointment
            .TopLevel = False
            Panel2.Controls.Add(frmAppointment)
            .BringToFront()
            .Show()
            frmPersonalDetails.Hide()
            frmVaccineRecord.Hide()
        End With
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        Dim response As Integer

        response = MessageBox.Show("Are you sure you want to Logout", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If response = vbYes Then
            Application.Exit()
        End If
    End Sub
End Class